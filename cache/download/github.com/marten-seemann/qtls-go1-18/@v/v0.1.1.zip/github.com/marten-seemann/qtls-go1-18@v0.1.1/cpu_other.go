//go:build js
// +build js

package qtls

var (
	hasGCMAsmAMD64 = false
	hasGCMAsmARM64 = false
	hasGCMAsmS390X = false

	hasAESGCMHardwareSupport = false
)
